﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.ClientSideComponent;



namespace KSI_List_ReportProcessing
{
    class Program
    {
        static void Main(string[] args)
        {
            ClientContext ctx = SPHelpers.QueryAssistants.getProjectSpCtx(new Uri("https://kineticsys.sharepoint.com/sites/projects"));
            
            Web oWebsite = ctx.Web;
            List oList = ctx.Web.Lists.GetByTitle("KPPS Projects Catalog");

            CamlQuery camlQuery = new CamlQuery() { ViewXml = "<View><Query><Where><Eq><FieldRef Name='Status' /><Value Type='Choice'>Active</Value></Eq></Where></Query><ViewFields><FieldRef Name='Title' /><FieldRef Name='Proj_x0020_Site_x0020_URL' /></ViewFields><QueryOptions /></View>" };
            ListItemCollection items = oList.GetItems(camlQuery);
            ctx.Load(items);
            ctx.ExecuteQuery();
            foreach (ListItem item in items)
            {
                Console.Write(item["Proj_x0020_Site_x0020_URL"]);
                var url = item["Proj_x0020_Site_x0020_URL"].ToString();
                var Uri = new Uri(url);

                getListItemRollup(Uri, ctx);

                Console.Read();
            }
        }

        public static void getListItemRollup(Uri uri, ClientContext ctx) {
            List oList = ctx.Web.Lists.GetByTitle(uri + "/ITL");
            CamlQuery q = new CamlQuery() { ViewXml = "<View><Query /><ViewFields><FieldRef Name='qh8m' /><FieldRef Name='ip0d' /><FieldRef Name='h7r6' /><FieldRef Name='nigq' /></ViewFields><QueryOptions /></View>" };

            oList.GetItems(q).ToDictionary<>

                oList.item

            var q = new CamlQuery() { ViewXml = "<View><Query /><ViewFields><FieldRef Name='qh8m' /><FieldRef Name='ip0d' /><FieldRef Name='h7r6' /><FieldRef Name='nigq' /></ViewFields><QueryOptions /></View>" };
                var r = list.GetItems(q);
                ctx.Load(r);
                ctx.ExecuteQuery();
            }


        DataTable dt = oList.GetItems(query).GetDataTable();





        CamlQuery camlQuery = new CamlQuery();
            camlQuery.ViewXml = "<View><Query><Where><Eq><FieldRefName='" + fieldInternalName + "'/><Eq><Value Type='Text'>Belgium</Value></Eq></Where></Query></View>";
            var itemColl = list.GetItems(camlQuery);
            clientContext.Load(itemColl);
            clientContext.ExecuteQuery();

            var count = itemColl.Count;



        }
    }



}

